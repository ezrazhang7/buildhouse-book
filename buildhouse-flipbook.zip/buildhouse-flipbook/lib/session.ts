// Session tokens for the mentor gate. Web Crypto only, so it runs the same in the proxy, in route handlers and in tests.

export const SESSION_COOKIE = 'bh_book';
export const SESSION_DAYS = 30;

const enc = new TextEncoder();

function b64url(bytes: ArrayBuffer): string {
  let s = '';
  for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function sha256(text: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(text)));
}

/** Compares in time that does not depend on where the inputs differ. */
function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

export type GateConfig = { password: string; secret: string };

/** Null when the deployment is missing its password or secret. The gate then stays shut for everyone. */
export function gateConfig(env: Record<string, string | undefined> = process.env): GateConfig | null {
  const password = env.MENTOR_PASSWORD ?? '';
  const secret = env.SESSION_SECRET ?? '';
  if (password.length < 8 || secret.length < 32) return null;
  return { password, secret };
}

export async function passwordMatches(attempt: string, cfg: GateConfig): Promise<boolean> {
  return sameBytes(await sha256(`pw:${attempt}`), await sha256(`pw:${cfg.password}`));
}

// The signing key mixes in the password, so changing the password signs every mentor out.
async function signingKey(cfg: GateConfig): Promise<CryptoKey> {
  const raw = await sha256(`${cfg.secret}\n${cfg.password}`);
  return crypto.subtle.importKey('raw', raw as BufferSource, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
}

async function sign(payload: string, cfg: GateConfig): Promise<string> {
  return b64url(await crypto.subtle.sign('HMAC', await signingKey(cfg), enc.encode(payload)));
}

export async function issueToken(cfg: GateConfig, now: number = Date.now()): Promise<string> {
  const payload = `v1.${Math.floor(now / 1000) + SESSION_DAYS * 86400}`;
  return `${payload}.${await sign(payload, cfg)}`;
}

export async function tokenIsValid(token: string | undefined, cfg: GateConfig | null, now: number = Date.now()): Promise<boolean> {
  if (!token || !cfg) return false;
  const parts = token.split('.');
  if (parts.length !== 3 || parts[0] !== 'v1' || !/^\d{1,12}$/.test(parts[1])) return false;
  if (Number(parts[1]) * 1000 <= now) return false;
  const expected = await sign(`${parts[0]}.${parts[1]}`, cfg);
  return sameBytes(enc.encode(parts[2]), enc.encode(expected));
}

/** Only same-site paths may follow a login, so the unlock page cannot be used to bounce mentors elsewhere. */
export function safeNext(next: string | null | undefined): string {
  if (!next || !next.startsWith('/') || next.startsWith('//') || next.includes('\\') || next.startsWith('/unlock') || next.startsWith('/api/')) return '/';
  return next;
}
