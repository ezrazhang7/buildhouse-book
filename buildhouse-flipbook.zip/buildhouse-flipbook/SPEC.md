# BuildHouse mentor book: spec

Written 2026-10-09. Describes what is built in this repo, what is stubbed, and what is left to decide.

## 1. What it is

A private website BuildHouse (Chapel Hill) sends to mentors. It reads like a bound book: a cover, a contents page, then one two-page spread per venture. A mentor flips through, sees who each founder is and what they asked for, and tells BuildHouse who they can help.

It replaces the Canva profile PDFs. Those are flat images that someone has to redo by hand every time a number changes. Here every page is live HTML drawn from one tab of the BuildHouse sheet.

**Readers:** mentors, on a laptop mostly, sometimes a phone. **Editors:** the BuildHouse team, in Google Sheets. Nobody edits the site itself.

## 2. Decisions made (change these if they are wrong)

| Decision | Chosen | Why | Cost of changing |
|---|---|---|---|
| Access | One shared password for all mentors | Simplest thing to hand out | Per-mentor links need a "Mentors" tab and a token check; about a day |
| Data source | A new **Profiles** tab in the existing sheet | The form-response tab mixes public copy with phone numbers, e-signatures and dues questions | None; the raw tab is never read by the site |
| Freshness | Sheet is read at build time, not on every page view | No Google call can fail while a mentor is reading, and credentials never run in the request path | Add a Vercel deploy hook button (section 7) for "publish now" |
| "I can help" | Goes to BuildHouse, not to the founder | Founders' contact details stay out of the book | n/a |
| Page turn | Own CSS 3D leaves, no flipbook library | Pages stay real DOM, so links, dialogs and filters work inside them | n/a |
| Phones | Swipe pager, one page at a time | A two-page spread is unreadable under about 900px wide | n/a |

## 3. Experience

Reading order: cover, how to read, contents, 17 venture spreads, back page.

- **Cover.** Title, count of ventures, edition (`BOOK_EDITION`).
- **How to read.** Three lines of instruction and a legend for the red markup.
- **Contents.** Every venture with its founders and sheet number. Chips filter by the kind of help founders asked for (11 fixed categories, counts shown). Clicking a venture riffles to it.
- **Venture spread, left page.** Tier and move-in month, venture name, one-liner, up to four stats, founders with portrait, title, LinkedIn and Instagram, venture links.
- **Venture spread, right page.** Founding story (fades out; "Read the full story" opens it in full), the ask inside a red revision cloud with the filterable needs and the founder's own words, an "I can help with this" button, and a title block with the sheet number.
- **Back page.** Offer help to any builder, back to contents, lock the book.

Ways to move: arrows beside the book, arrow keys, Page Up/Down, Home/End, swipe on touch screens, contents button. Each venture has its own address (`/#trybl`), which survives the password step, so BuildHouse can send a mentor straight to one founder.

Design: a set of drawings on a cutting mat. Paper pages, navy ink, non-photo-blue rules, and redline (the red a reviewer marks plans up with) used only for what a founder needs from a mentor. Type is Big Shoulders Display for names and labels, Source Serif 4 for reading, Architects Daughter for the redline notes. Fonts are bundled, not loaded from Google.

Missing content shows as a plain line ("No founding story on file yet") so gaps are visible to BuildHouse instead of hidden.

## 4. Data

### The Profiles tab

One row per venture. Import `seed/profiles-tab.csv` to create it. Columns:

| Column | Format | Notes |
|---|---|---|
| publish | TRUE / FALSE | Only TRUE rows are built. Two seed rows are held back |
| slug | text, optional | Address of the spread. Made from the venture name if blank |
| venture | text | Required |
| one_liner | one sentence | |
| founders | one per line: `Name \| Title \| LinkedIn URL \| Instagram handle \| headshot Drive link` | Later fields optional |
| tier | as on the form | Anything in brackets (dues) is dropped |
| moved_in | date | Shown as month and year |
| days_in_space | text | Optional |
| story | paragraphs separated by a blank line | |
| stats | one per line: `Value \| Label` | Up to four |
| needs | separated by `;` | Must be from the list in `lib/profiles-map.mjs`; others are dropped with a build warning |
| ask | text | The founder's own words |
| links | one per line: `Label \| URL` | For Instagram a handle is enough |
| logo | Drive link | |
| notes | text | Internal. Never leaves the sheet |

Rules the mapper enforces: links must be http(s); Drive ids are stripped before anything reaches the browser; duplicate slugs are skipped with a warning.

### What the seed contains and where it came from

Built from the 22 form responses read on 2026-10-07 plus the three Canva profiles.

- 17 published, 2 held back (Kit 14 Public Relations and ThreatSecOps have no story or ask), 2 form rows skipped for having no venture, and the two Copperline rows merged.
- **Left out on purpose:** phone numbers, email addresses, e-signatures, dues, move-in questions.
- **Drafted by Claude, needs a founder's OK:** 14 of the 17 one-liners, written from each founding story. The `notes` column marks each one.
- **From the Canva designs:** one-liners and stats for TidalCleanse and Triangle Hydro Solutions. The "100+ homes" label was cut off in the export.
- **From founders' own stories:** every other stat.
- **Edited stories:** Trybl, Creset and Stomp Out Hunger were shortened. In the Stomp Out Hunger story the first name of the man the founder met was removed.
- **Still empty:** Markit Advertising (no one-liner, story or ask), TidalCleanse (story is a linked Google Doc), Triangle Hydro Solutions (no ask). The "pain points" form column only holds real answers from late August on; before that it holds orientation RSVPs, so earlier ventures' needs were read from their free-text support answer.
- **No photos or logos yet.** Portraits show initials. Single-founder rows already carry their headshot link; multi-founder teams need each photo matched to a name in the sheet. Speedy, which appears in the ChatGPT mockups, is not in the sheet and so not in the book.

### Sync

`npm run sync` (also runs before every build when credentials are set):

1. Reads `Profiles!A1:Z500` with a read-only service account.
2. Maps and validates rows, keeps published ones.
3. Downloads each headshot and logo from Drive into `public/media/<slug>/` (images only, 8 MB cap).
4. Writes `content/profiles.json`.
5. Refuses to build an empty book. Prints a warning for anything dropped.

Without credentials the build uses the committed `content/profiles.json`.

## 5. Access and privacy

- `proxy.ts` checks every request except `/unlock`, `/api/unlock`, `/robots.txt` and the compiled JS/CSS/fonts. No cookie means a redirect to `/unlock` (pages, images) or a 401 (API).
- The home page is rendered on the server per request, so founder data only exists in responses that passed the check. Compiled static files contain none of it.
- Password is compared in constant time. On success the server sets a 30-day cookie: `HttpOnly`, `Secure`, `SameSite=Lax`, signed with HMAC-SHA256. The signing key is derived from `SESSION_SECRET` and the password, so **changing the password signs every mentor out**.
- If `MENTOR_PASSWORD` (8+ characters) or `SESSION_SECRET` (32+) is missing, nobody gets in.
- Eight wrong tries per address per ten minutes, then a wait. This counter lives in one server instance's memory, so it slows guessing but does not stop a determined attacker; the password should be a long phrase.
- Headers on everything: `X-Robots-Tag: noindex`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer` (the book's address is not leaked to LinkedIn or Instagram on click-through), `Cache-Control: private, no-store` on gated responses. `robots.txt` disallows all.
- Limits of a shared password: it can be forwarded, and there is no record of which mentor opened what. Rotating it is the only way to revoke access.

## 6. "I can help with this"

Form: name, email, note. `POST /api/offer` checks the session again, validates, then delivers to whichever is configured:

- a row appended to the sheet's **Mentor offers** tab (time, venture, name, email, note). Needs the service account to have edit access and the tab to exist;
- a JSON POST to `OFFERS_WEBHOOK_URL`.

If neither is set, or delivery fails, the mentor sees an error with `CONTACT_EMAIL` as a fallback. Notes that start with `=`, `+`, `-` or `@` are escaped so they cannot run as formulas in the sheet.

## 7. Deploy (Vercel)

1. Push this repo to GitHub and import it in Vercel. Framework preset: Next.js.
2. Set `MENTOR_PASSWORD` and `SESSION_SECRET`. The book works at this point from the committed seed.
3. For live data: create a Google Cloud service account, enable the Sheets and Drive APIs, share the sheet and the form's upload folders with the account's email, and set `GOOGLE_SERVICE_ACCOUNT_EMAIL`, `GOOGLE_PRIVATE_KEY`, `SHEET_ID`.
4. For a "publish" button: create a Vercel deploy hook and call it from the sheet (Apps Script menu item) or on a daily schedule.
5. Add a custom domain if wanted.

## 8. Checked, and not checked

Checked on 2026-10-09 against a local production build: 14 unit tests (row mapping, link safety, token signing, expiry, tampering, password rotation); every route, image path and data path refuses a visitor without a cookie; forged cookie refused; compiled static files contain no founder data; the seed output contains no emails, phone numbers or dues; cover, contents filter, page turn, deep links, story and offer dialogs, and the phone pager driven in Chromium at 1440x900, 1280x640 and 390x844.

**Not checked:** the sheet sync and the sheet append against real Google APIs (no service account exists yet), a real Vercel deploy, Safari and Firefox, a screen reader pass.

## 9. Open questions for BuildHouse

1. Is one shared password acceptable, or do they need to revoke individual mentors?
2. Who approves the drafted one-liners: BuildHouse or each founder?
3. Should tier be shown to mentors at all?
4. Where should offers land: the sheet, Slack, email?
5. Do vendor residents (Kit 14) belong in a mentor book?

## 10. Later

Per-mentor links and an open log; real headshots and logos; drag-to-turn page curl; a print stylesheet; founders editing their own row through a form.
