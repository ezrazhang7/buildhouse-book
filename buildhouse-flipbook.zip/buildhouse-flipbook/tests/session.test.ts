import test from 'node:test';
import assert from 'node:assert/strict';
import { gateConfig, issueToken, passwordMatches, safeNext, tokenIsValid } from '../lib/session.ts';

const cfg = { password: 'correct horse battery', secret: 'x'.repeat(48) };

test('the gate stays shut without a real password and secret', () => {
  assert.equal(gateConfig({}), null);
  assert.equal(gateConfig({ MENTOR_PASSWORD: 'short', SESSION_SECRET: 'x'.repeat(48) }), null);
  assert.equal(gateConfig({ MENTOR_PASSWORD: 'long enough', SESSION_SECRET: 'tooshort' }), null);
});
test('password check', async () => {
  assert.equal(await passwordMatches('correct horse battery', cfg), true);
  assert.equal(await passwordMatches('correct horse batterx', cfg), false);
  assert.equal(await passwordMatches('', cfg), false);
});

test('a fresh token is valid, then expires', async () => {
  const now = Date.UTC(2026, 9, 8);
  const token = await issueToken(cfg, now);
  assert.equal(await tokenIsValid(token, cfg, now), true);
  assert.equal(await tokenIsValid(token, cfg, now + 31 * 86400 * 1000), false);
});

test('tampered, forged and missing tokens are refused', async () => {
  const token = await issueToken(cfg);
  const [v, exp, sig] = token.split('.');
  assert.equal(await tokenIsValid(`${v}.${Number(exp) + 999999}.${sig}`, cfg), false);
  assert.equal(await tokenIsValid(`${v}.${exp}.${sig.slice(0, -2)}AA`, cfg), false);
  assert.equal(await tokenIsValid('v1.9999999999.AAAA', cfg), false);
  assert.equal(await tokenIsValid(undefined, cfg), false);
  assert.equal(await tokenIsValid(token, null), false);
});

test('changing the password or the secret signs everyone out', async () => {
  const token = await issueToken(cfg);
  assert.equal(await tokenIsValid(token, { ...cfg, password: 'a new password' }), false);
  assert.equal(await tokenIsValid(token, { ...cfg, secret: 'y'.repeat(48) }), false);
});

test('only same-site paths may follow a login', () => {
  assert.equal(safeNext('/'), '/');
  assert.equal(safeNext('/media/x.png'), '/media/x.png');
  assert.equal(safeNext('//evil.com'), '/');
  assert.equal(safeNext('https://evil.com'), '/');
  assert.equal(safeNext('/\\evil.com'), '/');
  assert.equal(safeNext('/unlock'), '/');
  assert.equal(safeNext(null), '/');
});
